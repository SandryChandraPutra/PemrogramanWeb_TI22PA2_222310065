<?php $__env->startSection('main-content'); ?>
    <div class="mt-3">
        <a href="/" class="text-decoration-none ">
            <i class="bi bi-arrow-left"></i>
            <span>Back to Dashboard</span>
        </a>
        <div class="fullname mt-4">
            <span class="text-secondary">Fullname :</span>
            <h2><?php echo e($fullname->fullname); ?></h2>
        </div>
        <div class="npm mt-4">
            <span class="text-secondary">Npm :</span>
            <h2><?php echo e($npm->npm); ?></h2>
        </div class="email mt-4">
            <span class="text-secondary">Email :</span>
            <h2><?php echo e($email->email); ?></h2>
        </div>
        </div class="prodi mt-4">
            <span class="text-secondary">Prodi :</span>
            <h2><?php echo e($prodi->prodi); ?></h2>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Murid.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-student\resources\views/Murid/modules/students/show.blade.php ENDPATH**/ ?>